﻿using Animals;
using System.Xml.Linq;

// Create instance of object
var rex = new Dog("Rex", 5);
var whiskers = new Cat("Whiskers", 3);
var tweety = new Bird("Tweety", 1);
Console.WriteLine($"Initial instance object:\n{rex}\n{whiskers}\n{tweety}");

var animals = new List<Animal>();
animals = [rex, whiskers, tweety];

// added class1 to add edit delete pet
new Class(animals);

